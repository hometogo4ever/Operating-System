//----------------------------------------------------------------
//
//  4190.307 Operating Systems (Spring 2024)
//
//  Project #4: KSM (Kernel Samepage Merging)
//
//  May 7, 2024
//
//  Dept. of Computer Science and Engineering
//  Seoul National University
//
//----------------------------------------------------------------

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "ksm.h"

struct meta {
  int vp;
  int zp;
  int up;
  int mp;
};
struct meta metalist[3];

int zerocount = 0;

extern struct proc proc[NPROC];
int rfidx = 0;
struct ref_pte ref_list[MAXPATH];
struct hash_bucket hb_list[MAXPATH]; // has information about shared physical address, pid, hash value
int index = 1;


pte_t zero_page;

void 
initzeropage() {
  char *zero_page_init;
  if ((zero_page_init = kalloc()) != 0) {
    zero_page = PA2PTE((uint64)zero_page_init) | PTE_V | PTE_R;

    struct hash_bucket *hb;
    struct proc_va_pair tempair;
    pte_t *pte = &zero_page;

    
    tempair.pid = 0;
    tempair.va = 0;
    tempair.pt = 0;
    tempair.pte = *pte;
    hb = &hb_list[0];
    hb->pair = tempair;
    hb->count = 0;
    hb_list[0] = *hb;
  }
  else {
    panic("Zero Page Cannot be allocated.");
  }
}

uint64
sys_ksm(void)
{
    struct proc *p = myproc();
    uint64 scanned;
    uint64 merged;
    argaddr(0, &scanned);
    argaddr(1, &merged);
    int s = 0;
    int m = 0;
    proc_ksm(&s, &m);
    copyout(p->pagetable, scanned, (char*)&s, sizeof(int));
    copyout(p->pagetable, merged, (char*)&m, sizeof(int));
  return freemem;
}
void
proc_ksm(int * scanned, int * merged) {
  int vp = 0;
  int zp = 0;
  int mp = 0;
  int up = 0;

  struct proc *p;
  struct ref_pte rf;
  struct hash_bucket *hb;
  struct proc_va_pair tempair;
  struct hash_bucket newhb;

  // Collecting hash value of Physical address
  for (p = proc; p<&proc[NPROC]; p++) {
    if (p->pid == 1 || p->pid == 2 || p->pid == myproc()->pid || p->pid == 0) {
      continue;
    }
    pagetable_t pt = p->pagetable;
    for (uint64 va = 0; va < p->sz; va+= PGSIZE) {
      *scanned += 1;
      pte_t *part = walk(pt, va, 0);
      uint64 *pa = (uint64 *)PTE2PA(*part);
      if (pa != 0 && !(*part & PTE_C)) {
        int iszero = 0;
        for (uint64 *pa2=pa; pa2<pa+PGSIZE/8; pa2+=1){
          if (*pa2 != 0) {
            iszero = 1;
            break;
          }
        }
        if (iszero == 0) {
          kfree(pa);
          hb = &hb_list[0];
          hb->count += 1;
          zerocount += 1;

          *walk(pt, va, 0) = zero_page | PTE_C;
          *merged += 1;
        }
        else {
          uint64 hsh = xxh64(pa, PGSIZE);
          int hasvalue = 0;
          for (hb = hb_list; hb<&hb_list[index]; hb++){
            if (hb->hash_value == hsh) {
              if (hb->pair.pid == p->pid && hb->pair.va == va) {
                hasvalue = 1;
                break;
              }
              if (!hb->count) {
                tempair = hb->pair;
                pte_t temporary_pte = (*walk(tempair.pt, tempair.va, 0) & ~PTE_W) | PTE_C;
                *walk(tempair.pt, tempair.va, 0) = temporary_pte;
                tempair.pte = temporary_pte;

                hb->pair = tempair;
                
                rf = ref_list[rfidx];
                rf.ref = 1;
                rf.pair[0] = tempair;
                ref_list[rfidx] = rf;
                rfidx += 1;
              }
              if (hb->count < 15) {
                hb->count += 1;
                tempair = hb->pair;
                kfree(pa);
                *merged += 1;

                *walk(pt, va, 0)= tempair.pte;
                mp++;
                for (int v = 0;v < rfidx; v++) {
                  rf = ref_list[v];
                  if (rf.pair[0].pte == tempair.pte) {
                    tempair.pid = p->pid;
                    tempair.pt = pt;
                    tempair.va = va;
                    tempair.pte = *part;
                    rf.pair[rf.ref] = tempair;
                    rf.ref += 1;
                    ref_list[v] = rf;
                    hasvalue = 1;
                    break;
                  }
                }
              } 
              break;
            }
          }
          if (!hasvalue) {
            newhb.hash_value = hsh;
            newhb.count = 0;

            tempair.pid = p->pid;
            tempair.va = va;
            tempair.pt = pt;
            tempair.pte = *part;
            newhb.pair = tempair;
            up++;
            hb_list[index] = newhb;
            index += 1;
          }
        }
      }
    }
  }
  struct meta mt;
  mt.mp = mp;
  mt.up = up;
  mt.vp = vp;
  mt.zp = zp;
  metalist[0] = mt;
}

