//----------------------------------------------------------------
//
//  4190.307 Operating Systems (Spring 2024)
//
//  Project #4: KSM (Kernel Samepage Merging)
//
//  May 7, 2024
//
//  Dept. of Computer Science and Engineering
//  Seoul National University
//
//----------------------------------------------------------------


#include "types.h"
#include "param.h"

extern int freemem;

struct proc_va_pair {
    int pid;
    uint64 va;
    pagetable_t pt;
    pte_t pte;
};

struct hash_bucket {
    uint64 hash_value;
    struct proc_va_pair pair;
    int count;
};

struct ref_pte {
    int ref;
    struct proc_va_pair pair[16];
};

struct debug {
    int pid;
    uint64 va;
    pte_t pte;
    pte_t newpte;
    int bool;
    struct debug *next;
};

